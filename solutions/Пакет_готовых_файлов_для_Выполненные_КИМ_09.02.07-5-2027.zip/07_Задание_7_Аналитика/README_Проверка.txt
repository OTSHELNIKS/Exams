Файлы clean_dataset_2026.xlsx и analysis_2026.xlsx уже готовы; пересобирать их для сдачи не требуется.

Для локальной предварительной проверки явных критериев из ТЗ запустите в этой папке:
  python preflight_check.py

Нужен openpyxl (pip install -r requirements_task7.txt). Скрипт сверит 30 строк, типы, ID, категории, выручку, 12 месяцев, итоги и график. Он НЕ является официальным Analytics_autotest и НЕ выдаёт код 7.1.

Если нужно самостоятельно перестроить результаты, используйте:
  python clean_data.py --input dataset_2026.xlsx --clean-output clean_dataset_2026.xlsx --analysis-output analysis_2026.xlsx
