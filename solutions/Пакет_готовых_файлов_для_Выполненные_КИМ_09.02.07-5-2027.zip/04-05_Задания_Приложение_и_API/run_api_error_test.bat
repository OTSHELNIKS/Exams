@echo off
cd /d "%~dp0"
set EXAM_TEST_MODE=1
set EXAM_FORCE_DB_ERROR=1
set APP_PORT=8001
set EXAM_DB_PATH=%TEMP%\exam_api_fault.sqlite3
python app.py
pause
