#!/usr/bin/env sh
cd "$(dirname "$0")"
EXAM_TEST_MODE=1 EXAM_FORCE_DB_ERROR=1 APP_PORT=8001 EXAM_DB_PATH="${TMPDIR:-/tmp}/exam_api_fault.sqlite3" python3 app.py
